package it.polimi.tiw.project.dao;

import it.polimi.tiw.project.beans.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProjectDAO extends DAO {

    public ProjectDAO(Connection connection) {
		super(connection);
    }

    // 1. Estrazione Progetti del Responsabile (Tecnico_nome_utente)
    public List<Project> findManagerProjects(int manager) throws SQLException {
        List<Project> projects = new ArrayList<>();
        
        // Tabella 'Progetto', la FK verso il responsabile è 'Tecnico_nome_utente'
        String projectQuery = "SELECT titolo, durata, stato FROM Progetto WHERE responsabile = ?";
        
        try (PreparedStatement pstatement = connection.prepareStatement(projectQuery)) {
            pstatement.setInt(1, manager);
            try (ResultSet resultSet = pstatement.executeQuery()) {
                while (resultSet.next()) {
                    Project project = new Project();
                    project.setTitolo(resultSet.getString("titolo"));
                    project.setDurata(resultSet.getInt("durata"));
                    project.setStato(resultSet.getString("stato"));
                    
                    // Riempimento ricorsivo di WP e Task passando la PK del progetto (titolo)
                    project.setWp(findWPsByProject(project.getTitle()));
                    
                    projects.add(project);
                }
            }
        }
        return projects;
    }

    // 2. Estrazione Work Packages
	public List<WorkPackage> findWPsByProject(String projectTitle) {
        List<WorkPackage> wps = new ArrayList<>();
        
        String query = "SELECT * FROM Work_Package WHERE progetto = ?";
        
        try (PreparedStatement pstatement = connection.prepareStatement(query)) {
            pstatement.setString(1, projectTitle);
            
            try (ResultSet result = pstatement.executeQuery()) {
                while (result.next()) {
                    WorkPackage wp = new WorkPackage();
                    wp.setIdOrder(result.getInt("numero_ordine"));
                    wp.setTitle(result.getString("titolo"));
                    wp.setStartMonth(result.getInt("mese_inizio"));
                    wp.setEndMonth(result.getInt("mese_fine"));
                    
                    wps.add(wp);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return wps;
    }

    // 3. Estrazione Task
	public List<Task> findTasksByWP(String projectTitle, int wp) {
		List<Task> tasks = new ArrayList<>();

		String query = "SELECT * FROM Task WHERE progetto = ? AND wp = ?";

		try (PreparedStatement pstatement = connection.prepareStatement(query)) {
			pstatement.setString(1, projectTitle);
			pstatement.setInt(2, wp);

			try (ResultSet result = pstatement.executeQuery()) {
				while (result.next()) {
					Task task = new Task();
					task.setIdOrder(result.getInt("numero_ordine"));
					task.setTitle(result.getString("titolo"));
					task.setDescription(result.getString("descrizione"));
					task.setStartMonth(result.getInt("Mese_inizio"));
					task.setEndMonth(result.getInt("Mese_fine"));

					tasks.add(task);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return tasks;
	}

    // 4. L'Assegnazione (La parte più colpita dallo schema DB)
    public void assignCollaborator(String progetto, String wp, String task, String mese, String collaboratore, int ore) throws SQLException {
        // Poiché dobbiamo scrivere su due tabelle diverse (Task_ha_Tecnico e Task_has_Mese), 
        // usiamo una transazione per evitare dati parziali in caso di errore.
        
        String insertTecnicoTask = """
        		
					        		INSERT IGNORE INTO Task_ha_Tecnico
					        		(collaboratore, task, wp, progetto) 
					        		VALUES (?, ?, ?, ?)
					        		
        							""";

        String insertOreMese = "INSERT INTO Task_has_Mese " +
                               "(task, wp, progetto, mese, ore_previste) " +
                               "VALUES (?, ?, ?, ?, ?)";

        try {
            connection.setAutoCommit(false); // Inizio transazione

            // 1. Assegno il tecnico al task (uso INSERT IGNORE in caso sia già assegnato in un altro mese)
            try (PreparedStatement psTecnico = connection.prepareStatement(insertTecnicoTask)) {
                psTecnico.setString(1, collaboratore);
                psTecnico.setString(2, task);
                psTecnico.setString(3, wp);
                psTecnico.setString(4, progetto);
                psTecnico.executeUpdate();
            }

            // 2. Registro le ore previste per quel mese specifico
            try (PreparedStatement psMese = connection.prepareStatement(insertOreMese)) {
                psMese.setString(1, task);
                psMese.setString(2, wp);
                psMese.setString(3, progetto);
                psMese.setString(4, mese);
                psMese.setInt(5, ore);
                psMese.executeUpdate();
            }

            // Opzionale: Aggiungerlo anche a Progetto_ha_Collaboratori se non c'è già? 
            // Dipende se quel legame viene creato prima, ma a giudicare dall'ER ha senso farlo.

            connection.commit(); // Confermo transazione
        } catch (SQLException e) {
            connection.rollback(); // Annulla tutto in caso di errore (es. Foreign Key fallita)
            throw e;
        } finally {
            connection.setAutoCommit(true); // Ripristino il comportamento di default
        }
    }
}