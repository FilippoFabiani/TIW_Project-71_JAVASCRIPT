package it.polimi.tiw.project.controllers;

import jakarta.servlet.ServletContextListener;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.WebApplicationTemplateResolver;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import jakarta.servlet.ServletContext;

@jakarta.servlet.annotation.WebListener
public class ListenerThymeleaf implements ServletContextListener {

	@Override
	public void contextInitialized(jakarta.servlet.ServletContextEvent sce) {
        ServletContext servletContext = sce.getServletContext();
        
        JakartaServletWebApplication application = JakartaServletWebApplication.buildApplication(servletContext);
        
        WebApplicationTemplateResolver templateResolver = new WebApplicationTemplateResolver(application);
        templateResolver.setPrefix("/WEB-INF/templates/");
        templateResolver.setSuffix(".html");
        templateResolver.setTemplateMode(TemplateMode.HTML);
        templateResolver.setCharacterEncoding("UTF-8");

        TemplateEngine templateEngine = new TemplateEngine();
        templateEngine.setTemplateResolver(templateResolver);

        servletContext.setAttribute("templateEngine", templateEngine);
        
        System.out.println("Thymeleaf inizializzato con successo all'avvio del server!");
	}

	@Override
	public void contextDestroyed(jakarta.servlet.ServletContextEvent sce) {
		//TODO 
		// No cleanup needed for Thymeleaf in this case
	}

}
