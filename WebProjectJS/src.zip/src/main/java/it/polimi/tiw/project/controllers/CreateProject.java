package it.polimi.tiw.project.controllers;


import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import it.polimi.tiw.project.beans.User;
import it.polimi.tiw.project.dao.AdminDAO;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/CreateProject")
public class CreateProject extends MyServlet {
    private static final long serialVersionUID = 1L;


	public CreateProject() {
		super();
	}

  
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		// sanification
		String projectName = request.getParameter("projectName");
		// TODO check wheter it already exists in the db
		int durata = 0;
		int responsabile = 0;
		try {		
			durata = Integer.parseInt(request.getParameter("projectDuration"));
			responsabile = Integer.parseInt(request.getParameter("projectManager"));
        } catch (NumberFormatException e) {
            // Handle the error, maybe set a default value or return an error response
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid project duration or manager ID");
            return;
        }
		
				
		HttpSession session = request.getSession(false); 
		
		if (session == null || session.getAttribute("user") == null) {
			response.sendRedirect(request.getContextPath() + "/login.html");
			return;
		}
		
		User admin = (User) session.getAttribute("user");
		AdminDAO adminDAO = null;
		
	    try (Connection connection = getConnection()) {
			adminDAO = new AdminDAO(connection);
			
	    	adminDAO.createProject(projectName, durata, responsabile, admin.getId());
	        
	    } catch (SQLException e) {
	    	//TODO gestisci l'errore (es. inoltra a una pagina di errore)
	        // gestisci l'errore (es. inoltra a una pagina di errore)
	    }
	}
	
}
