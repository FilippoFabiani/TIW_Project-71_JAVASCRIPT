package it.polimi.tiw.project.controllers;

import org.thymeleaf.context.WebContext;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Starting servelet, it initializes and sends the login page.
 * */
@WebServlet({"/login", ""}) 
public class Login extends MyServlet {
	static final long serialVersionUID = 1L;


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");

        var webExchange = this.application.buildExchange(request, response);
        WebContext context = new WebContext(webExchange);

        templateEngine.process("login", context, response.getWriter());
    }
}