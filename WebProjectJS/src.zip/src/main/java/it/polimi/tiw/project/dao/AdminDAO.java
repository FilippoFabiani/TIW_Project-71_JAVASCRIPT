package it.polimi.tiw.project.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import it.polimi.tiw.project.beans.Project;
import it.polimi.tiw.project.beans.User;
import it.polimi.tiw.project.beans.WorkPackage;

public class AdminDAO extends DAO {
	
	public AdminDAO(java.sql.Connection connection) {
		super(connection);
	}
	
	/**
	 *  triggered when admin presses SAVE botton in the create project page, it saves the project in the db
	 * */
	public void createProject(String progetto, int durata, int responsabile, int admin) {
		String query = """
				
						INSERT INTO Progetto (titolo, durata, stato, responsabile, amministratore) 
	                    VALUES (?, ?, 'creato', ?, ? )
		                    
						""";
		
		try (PreparedStatement pstatement = connection.prepareStatement(query)) {
			pstatement.setString(1, progetto);
			pstatement.setInt(2, durata);
			pstatement.setInt(3, responsabile);
			pstatement.setInt(4, admin);

			pstatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}
	/**
	 *  saves in DB a new wp
	 * */
	public void createWp(String progetto, String titolo, int meseInizio, int meseFine) {
		String query = """

						INSERT INTO Work_Package (titolo, Mese_inizio, Mese_fine, progetto)
						VALUES (?, ?, ?, ?)
		
						""";

		try (PreparedStatement pstatement = connection.prepareStatement(query)) {
			pstatement.setString(1, titolo);
			pstatement.setInt(2, meseInizio);
			pstatement.setInt(3, meseFine);
			pstatement.setString(4, progetto);

			pstatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	/**
	 *  saves in DB a new task
	 * */
	public void createTask(String progetto, String titolo, int wp, int meseInizio, int meseFine, String descrizione) {
		String query = """

			            INSERT INTO Task (titolo, Mese_inizio, Mese_fine, wp, progetto, descrizione)
			            VALUES (?, ?, ?, ?, ?, ?)
				
						""";
		
		try (PreparedStatement pstatement = connection.prepareStatement(query)) {
			pstatement.setString(1, titolo);
			pstatement.setInt(2, meseInizio);
			pstatement.setInt(3, meseFine);
			pstatement.setInt(4, wp);
			pstatement.setString(5, progetto);
			pstatement.setString(6, descrizione);

			pstatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * gets the list of projects created by the admin
	 * */
	public List<Project> getAdminProjects(User admin ) {
		// project first
		List<Project> projects = new ArrayList<>();
		List<WorkPackage> wps = new ArrayList<>();
		
		ProjectDAO projectDAO = new ProjectDAO(connection);
		

		String query = """
				
						SELECT * FROM Progetto WHERE amministratore = ?
						
						""";
		
		try (PreparedStatement pstatement = connection.prepareStatement(query)) {
			pstatement.setInt(1, admin.getId());
			
			try (ResultSet result = pstatement.executeQuery()) {
				if (!result.isBeforeFirst())
					//TODO gestire
					return null;
				else {
					
					Project project;
					
					while(result.next()) {
						project = new Project();
						project.setTitolo(result.getString("titolo"));
						project.setDurata(result.getInt("durata"));
						project.setStato(result.getString("stato"));
						project.setManager(result.getInt("responsabile"));
						project.setAdmin(result.getInt("amministratore"));
						projects.add(project);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
			
		// fillin' the project
		for(Project project : projects) {
			wps = projectDAO.findWPsByProject(project.getTitle());
			for (WorkPackage wp : wps) {
				wp.setTasks(projectDAO.findTasksByWP(project.getTitle(), wp.getIdOrder()));
			}
			project.setWp(wps);
		}
	
					
		return projects;
	}
	
	public List<User> getAllTechnicians() {
		List<User> users = new ArrayList<>();

		String query = """

						SELECT id, nome, cognome 
						FROM User JOIN Tecnico ON User.id = Tecnico.id
						WHERE position != 'admin'
		
						""";

		try (PreparedStatement pstatement = connection.prepareStatement(query)) {

			try (ResultSet result = pstatement.executeQuery()) {
				if (!result.isBeforeFirst())
					// TODO gestire
					return null;
				else {

					User user;

					while (result.next()) {
						user = new User();
						user.setId(result.getInt("id"));
						user.setName(result.getString("nome"));
						user.setSurname(result.getString("cognome"));
						users.add(user);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return users;
	}
	

	
}
