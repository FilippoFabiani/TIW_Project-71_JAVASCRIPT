package it.polimi.tiw.project.controllers;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import it.polimi.tiw.project.beans.Position;
import it.polimi.tiw.project.beans.User; 

@WebServlet("/redirect-technician")
public class redirectTechnician extends MyServlet {
	private static final long serialVersionUID = 1L;

	
	/**
	 * checks if the user is a technician.
	 * the session contains the uderId, in order to not mantain username and password, the user object is stored in the session.
	 * */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// 1. CONTROLLO ESISTENZA SESSIONE
		HttpSession session = request.getSession(false);

		if (session == null || session.getAttribute("user") == null) {
			response.sendRedirect(request.getContextPath() + "/login.html");
			return;
		}

		// 2. CONTROLLO AUTORIZZAZIONE (RUOLO)
		//TODO sinitize input
		User user = (User) session.getAttribute("user");
		Position position = user.getPosition();

		if (!Position.TECHNICIAN.equals(position)) {
			response.sendError(HttpServletResponse.SC_FORBIDDEN, "Accesso negato: profilo di tecnico richiesto.");
			return;
		}

		// 3. REINDIRIZZAMENTO
		response.sendRedirect(request.getContextPath() + "/homeTechnician.html");
	
	}
}
