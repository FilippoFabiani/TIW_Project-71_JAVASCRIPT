package it.polimi.tiw.project.controllers;

import java.io.IOException;

import org.thymeleaf.context.WebContext;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.sql.Connection;
import java.sql.SQLException;

import it.polimi.tiw.project.beans.User;
import it.polimi.tiw.project.beans.UserCredential;
import it.polimi.tiw.project.dao.UserCredentialDAO;
import it.polimi.tiw.project.exceptions.BusinessException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/CheckLogin")
public class CheckLogin extends MyServlet {
	
    private static final long serialVersionUID = 1L; 
    
	public CheckLogin() {
		super();
	}
    
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String usrn = null;
		String pwd = null;
		
		try {
			usrn = request.getParameter("username");
			pwd = request.getParameter("pwd");
			
			if (usrn == null || pwd == null || usrn.isEmpty() || pwd.isEmpty()) {
				//TODO not an exception, the user must rewrite the credentials, maybe redirect to login page with error message
				throw new Exception("Missing or empty credential value");
			}

		} catch (Exception e) {
			// for debugging only e.printStackTrace();
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing credential value");
			return;
		}

		// query db to authenticate for user
		UserCredentialDAO userDao = null;
		UserCredential credential = null;
		User user = null;
		
		//autoclosable connection, if an exception is thrown the connection is closed and the exception is propagated
		try (Connection connection = getConnection()) {
			userDao = new UserCredentialDAO(connection);
			credential = new UserCredential(usrn, pwd);
			
			try {
				user = userDao.checkCredential(credential);
			} catch (SQLException e) {
				//TODO manage exception, creating an handling servlet
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not Possible to check credentials");
				e.printStackTrace();
				return;
			} catch (BusinessException e){
				//TODO manage business exception, creating an handling servlet 
				// maybe each page can have a error message to show the user
			}
			
		} catch (SQLException e) {
			// TODO manage exception, creating an handling servlet
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Not Possible to check credentials");
			e.printStackTrace();
			return;
			}
		


		// If the user exists, add info to the session and go to home page, otherwise
		// show login page with error message

		String path;
        WebContext ctx = new WebContext(application.buildExchange(request, response), request.getLocale());
        
		if (user == null) {
			ctx.setVariable("errorMsg", "Incorrect username or password");
			path = "login";
		} else {
			request.getSession().setAttribute("user", user);
			switch (user.getPosition()) {
				case ADMIN:
					path = "homeAdministrator";
					break;
				case MANAGER:
					path = "homeManager";
					break;
				case COLLABORATOR:
					path = "homeCollaborator";
					break;
				case TECHNICIAN:
					path = "chooseHome";
					break;
				default:
					//TODO controllare se ha senso questa gestione
					path = "login";
					request.getSession().setAttribute("user", null);
					break;
			}
		
		templateEngine.process(path, ctx, response.getWriter());

		}
	
    }
	
	
}