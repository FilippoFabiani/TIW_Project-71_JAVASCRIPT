package it.polimi.tiw.project.controllers;

import it.polimi.tiw.project.beans.*;
import it.polimi.tiw.project.dao.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import com.google.gson.Gson;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/GetManagerData")
public class GetManagerData extends MyServlet {
    private static final long serialVersionUID = 1L;


    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Controllo Sessione Utente
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user"); // Presume che il login salvi l'username in sessione
        
        if (user == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().println("Utente non loggato");
            return;
        }

	    try (Connection connection = getConnection()) {
	        ProjectDAO projectDAO = new ProjectDAO(connection);
	        try {
	            // Estrazione dati
	            List<Project> projects = projectDAO.findManagerProjects(user.getId());
	            
	            // Conversione in JSON tramite Gson
	            String json = new Gson().toJson(projects);
	            
	            response.setContentType("application/json");
	            response.setCharacterEncoding("UTF-8");
	            response.setStatus(HttpServletResponse.SC_OK);
	            response.getWriter().write(json);
	            
	        } catch (SQLException e) {
	            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
	            response.getWriter().println("Errore nel recupero dei dati dal database");
	        }
	    
	        // usa connection per le query
	    } catch (SQLException e) {
	        // gestisci l'errore (es. inoltra a una pagina di errore)
	    }
    }
}