package it.polimi.tiw.project.controllers;

import java.io.IOException;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import it.polimi.tiw.project.beans.Position;
import it.polimi.tiw.project.beans.User; 

@WebServlet("/redirect-position")
public class RedirectHomePage extends MyServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		// 1. CONTROLLO ESISTENZA SESSIONE
		HttpSession session = request.getSession(false); 
		
		if (session == null || session.getAttribute("user") == null) {
			response.sendRedirect(request.getContextPath() + "/login.html");
			return;
		}
		
		// 2. CONTROLLO AUTORIZZAZIONE (RUOLO)
		User user = (User) session.getAttribute("user");
		Position position = user.getPosition();
		
		if (!Position.MANAGER.equals(position) && !Position.COLLABORATOR.equals(position) && !Position.TECHNICIAN.equals(position)) {
			response.sendError(HttpServletResponse.SC_FORBIDDEN, "Accesso negato: profilo di tecnico richiesto.");
			return;
		}
		
		// 3. REINDIRIZZAMENTO
		String choosenSring = request.getParameter("position");
        WebContext ctx = new WebContext(application.buildExchange(request, response), request.getLocale());

		if (choosenSring == null || choosenSring.isEmpty()) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Parametro 'position' mancante o vuoto.");
			return;
		}
		Position choosen = Position.valueOf(choosenSring.toUpperCase());
		String path = "";
		
		if (Position.COLLABORATOR.equals(choosen) && Position.COLLABORATOR.equals(position)) {
			path = "/homeCollaborator";
		} else if (Position.MANAGER.equals(choosen) && (Position.MANAGER.equals(position) || Position.TECHNICIAN.equals(position))) {
			path = "/homeManager";
		} else {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Azione non consentita per il tuo ruolo.");
			return;
		}
		
		// 4. ESECUZIONE DELLA GET SUCCESSIVA
		this.templateEngine.process(path, ctx, response.getWriter());
	}

	//TODO mettere in un controller dedicato per la redirect al login
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		response.sendRedirect(request.getContextPath() + "/login.html");
	}
}



