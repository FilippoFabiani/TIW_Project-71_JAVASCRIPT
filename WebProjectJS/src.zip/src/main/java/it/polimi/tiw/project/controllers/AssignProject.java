package it.polimi.tiw.project.controllers;

import it.polimi.tiw.project.dao.*;
import it.polimi.tiw.project.beans.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/AssigneProject")
public class AssignProject extends MyServlet {
    private static final long serialVersionUID = 1L;




    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Leggiamo l'azione dal bottone cliccato nell'HTML
        String azione = request.getParameter("azione");
        
        // Leggiamo i parametri che potrebbero essere stati inviati
        String progetto = request.getParameter("progetto");
        String wp = request.getParameter("wp");
        String task = request.getParameter("task");
        
		try (Connection connection = getConnection()) {
			ProjectDAO projectDAO = new ProjectDAO(connection);
	        
	        // Il percorso della tua pagina template (es. se usi Thymeleaf o JSP in WEB-INF)
	        String targetPath = "/WEB-INF/home_responsabile.html"; 

	        try {
	            if ("carica_wp".equals(azione)) {
	                // STEP 1: L'utente ha scelto il Progetto. Estraiamo i WP.
	                if (progetto != null && !progetto.isEmpty()) {
	                    List<WorkPackage> wps = projectDAO.findWPsByProject(progetto);
	                    
	                    // Salviamo i dati nella Request per il template HTML
	                    request.setAttribute("selectedProgetto", progetto); // Mantiene selezionato il progetto
	                    request.setAttribute("wpList", wps);                // Popola la tendina WP
	                }
	                // Rimanda alla pagina
	                request.getRequestDispatcher(targetPath).forward(request, response);

	            } 
	            else if ("carica_task".equals(azione)) {
	                // STEP 2: L'utente ha scelto il WP. Estraiamo i Task.
	                if (progetto != null && wp != null) {
	                    // Dobbiamo ricaricare anche i WP per non far svuotare la tendina precedente!
	                    List<WorkPackage> wps = projectDAO.findWPsByProject(progetto);
	                    List<Task> tasks = projectDAO.findTasksByWP(progetto, Integer.parseInt(wp));
	                    
	                    request.setAttribute("selectedProgetto", progetto);
	                    request.setAttribute("selectedWp", wp);
	                    request.setAttribute("wpList", wps);
	                    request.setAttribute("taskList", tasks); // Popola la tendina Task
	                }
	                request.getRequestDispatcher(targetPath).forward(request, response);

	            } 
	            else if ("assegna_definitivo".equals(azione)) {
	                // STEP 3: Submit finale dell'assegnazione
	                String mese = request.getParameter("mese");
	                String collaboratore = request.getParameter("collaboratore");
	                String oreStr = request.getParameter("ore");
	                
	                // Validazione server-side basilare
	                if (progetto == null || wp == null || task == null || mese == null || collaboratore == null || oreStr == null) {
	                    request.setAttribute("errorMessage", "Tutti i campi sono obbligatori.");
	                    // Ripopola tutto per non far perdere il form all'utente
	                    ripristinaStatoForm(request, projectDAO, progetto, wp);
	                    request.getRequestDispatcher(targetPath).forward(request, response);
	                    return;
	                }

	                try {
	                    int ore = Integer.parseInt(oreStr);
	                    // Esecuzione INSERT
	                    projectDAO.assignCollaborator(progetto, wp, task, mese, collaboratore, ore);
	                    
	                    // Se va a buon fine, mostriamo un messaggio di successo e resettiamo il form
	                    request.setAttribute("successMessage", "Collaboratore assegnato con successo!");
	                    request.getRequestDispatcher(targetPath).forward(request, response);
	                    
	                } catch (NumberFormatException e) {
	                    request.setAttribute("errorMessage", "Le ore devono essere un numero valido.");
	                    ripristinaStatoForm(request, projectDAO, progetto, wp);
	                    request.getRequestDispatcher(targetPath).forward(request, response);
	                }
	            }
	        } catch (SQLException e) {
	            request.setAttribute("errorMessage", "Errore di connessione al database.");
	            request.getRequestDispatcher(targetPath).forward(request, response);
	        }
			
		} catch (SQLException e) {
			request.setAttribute("errorMessage", "Errore di connessione al database.");
			request.getRequestDispatcher("/WEB-INF/home_responsabile.html").forward(request, response);
		}
        
    }

    // Metodo di supporto per evitare di riscrivere il codice di ricaricamento tendine in caso di errore
    private void ripristinaStatoForm(HttpServletRequest request, ProjectDAO dao, String progetto, String wp) throws SQLException {
        if (progetto != null) {
            request.setAttribute("selectedProgetto", progetto);
            request.setAttribute("wpList", dao.findWPsByProject(progetto));
            if (wp != null) {
                request.setAttribute("selectedWp", wp);
                request.setAttribute("taskList", dao.findTasksByWP(progetto, Integer.parseInt(wp)));
            }
        }
    }

}