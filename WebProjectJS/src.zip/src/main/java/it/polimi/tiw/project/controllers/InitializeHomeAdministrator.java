package it.polimi.tiw.project.controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;

import it.polimi.tiw.project.beans.*;
import it.polimi.tiw.project.dao.AdminDAO;
import it.polimi.tiw.project.dao.ProjectDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/RedirectAdmin")
public class InitializeHomeAdministrator extends MyServlet {

	private static final long serialVersionUID = 1L;

	public InitializeHomeAdministrator() {
		super();
	}

   
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	//elenco dei progetti creati, elenco dei wp creati, controllo doppioni di nomi nei progetti
		
		HttpSession session = request.getSession(false); 
		
		if (session == null || session.getAttribute("user") == null) {
			response.sendRedirect(request.getContextPath() + "/login.html");
			return;
		}
		
		User admin = (User) session.getAttribute("user");
		AdminDAO adminDAO = null;
		
		Project project = null;
		ProjectDAO projectDAO = null;
		List<User> technicians = null;
		
        try (Connection connection = getConnection()) {
        	adminDAO = new AdminDAO(connection);
        	projectDAO = new ProjectDAO(connection);
		    
        	request.setAttribute("technicians", adminDAO.getAllTechnicians());
        	request.setAttribute("projects", adminDAO.getAdminProjects(admin));
        	
        	
		    	
	    } catch (SQLException e) {
	    	//TODO gestisci l'errore (es. inoltra a una pagina di errore)
	        // gestisci l'errore (es. inoltra a una pagina di errore)
	    }
    
        WebContext ctx = new WebContext(application.buildExchange(request, response), request.getLocale());
        
        // Passi al motore il nome del file HTML (es. "homeAdmin.html")
        templateEngine.process("homeAdministrator", ctx, response.getWriter());
    
	} 
}
