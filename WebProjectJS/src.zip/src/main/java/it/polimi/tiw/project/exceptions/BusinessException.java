package it.polimi.tiw.project.exceptions;


/**
 * this class is a wrapper meant for {@link ErrorCode} class, in order to handle uniformly business logic errors
 * */
public class BusinessException extends RuntimeException {
	
    private final ErrorCode errorCode;

    public BusinessException(ErrorCode errorCode) {
        super(errorCode.getDefaultMessage());
        this.errorCode = errorCode;
    }

    public ErrorCode getErrorCode() {
        return errorCode;
    }
}
